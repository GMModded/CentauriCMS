<?php

use Centauri\CMS\Component\PageComponent;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

$controllerNamespace = "\\Centauri\\CMS\\Controller\\";

Route::get("/", function() {
    return PageComponent::request("/");
});

Route::post("/centauri/login", $controllerNamespace."BackendController@loginAction");
Route::get("/centauri/logout", $controllerNamespace."BackendController@logoutAction");

Route::get("{nodes}", function($nodes = []) {
    return PageComponent::request($nodes);
})->where(["nodes" => ".*"]);
