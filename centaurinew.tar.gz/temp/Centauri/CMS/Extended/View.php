<?php
namespace Centauri\CMS\Extended;

class View
{
    public static function loadBlades()
    {
        return [
            ""
        ];
    }
}
