<?php
namespace Centauri\CMS\Controller;

use Symfony\Component\HttpFoundation\Request;

class BackendController
{
    public function loginAction(Request $request)
    {
        $username = $request->input("username");
        $password = $request->input("password");

        if($username == "admin" && $password == "password") {
            session([
                "CENTAURI_BE_USER" => true
            ]);

            return redirect("/centauri");
        } else {
            return back()->withErrors(
                [
                    "LOGIN_FAILED_MESSAGE" => __("Username/password is wrong.")
                ]
            );
        }
    }

    public function logoutAction(Request $request)
    {
        session([
            "CENTAURI_BE_USER" => false
        ]);
        return redirect("/centauri");
    }
}
