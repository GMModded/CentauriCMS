<?php
namespace Centauri\CMS\Component;

class PageComponent
{
    /**
     * This function handles URL requests by $uri where that's a normal URL e.g. "/centauri" etc.
     * 
     * @param string $url
     * 
     * @return void
     */
    public static function request($url)
    {
        if($url == "/") {
            return view("frontend");
        }

        if($url == "centauri") {
            if(session()->has("CENTAURI_BE_USER") && session()->get("CENTAURI_BE_USER") == true) {
                return view("Backend.backend");
            } else {
                return view("Backend.login");
            }
        }
    }
}
