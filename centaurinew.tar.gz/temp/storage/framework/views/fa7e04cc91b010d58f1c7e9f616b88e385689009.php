<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Centauri - Backend</title>

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://kit.fontawesome.com/20ea993ef1.js" crossorigin="anonymous"></script>
    </head>

    <body>
        <style>
            html,
            body,
            #app {
                height: 100%;
                overflow: hidden;
                color: white;
            }



            #dashboard {
                position: relative;
                width: 300px;
                background: linear-gradient(180deg,#303a4f,#2a3345);
                transition: width .4s cubic-bezier(.5,.32,.01,1);
                height: 100%;
                display: flex;
                flex-direction: column;
            }

            #dashboard small {
                color: #d1d9e0;
                font-size: 70%;
                position: relative;
                top: -5px;
            }

            #dashboard #modules .module {
                display: flex;
                padding: 5px;
                cursor: pointer;
            }

            #dashboard #modules .module:hover {
                background: #364159;
            }

            #dashboard #modules .module .icon-view,
            #dashboard #user .avatar-view,
            #dashboard #user .dropdown-view .item .icon-view {
                margin: 10px 15px;
            }
            #dashboard #modules .module .text-view,
            #dashboard #user .text-view,
            #dashboard #user .dropdown-view .item .text-view {
                margin: 10px;
            }

            #dashboard #user .dropdown-view .item .icon-view {
                margin-left: 6.5px !important;
            }


            #dashboard #user {
                position: absolute;
                bottom: 0;
                width: 100%;
                border-top: 1px solid black;
                padding: 20px 0;
                background: #323c52;
            }
            #dashboard #user:hover {
                background: #364159;
            }

            #dashboard #user .text-view {
                margin-left: 0;
            }
            #dashboard #user .text-view p:first-child {
                font-weight: bold;
                margin-bottom: -5px !important;
            }
            #dashboard #user i {
                position: absolute;
                top: 15px;
                right: 15px;
                width: 63px;
                height: 63px;
                text-align: center;
                padding-top: 22.5px;
                cursor: pointer;
                transition: .3s;
            }
            #dashboard #user.active i {
                transform: rotate(-180deg);
            }

            #dashboard #user .avatar-view {
                display: inline-block;
                width: 40px;
                height: 40px;
                border-radius: 100%;
                background: #e0e6eb no-repeat 50%;
                background-size: cover;
                text-align: center;
                font-weight: 600;
                text-transform: uppercase;
                color: #fff;
                user-select: none;
                background-color: rgb(255, 215, 0);
                font-size: 16px;
                line-height: 39px;
            }

            #dashboard #user .dropdown-view .item {
                padding: 15px;
                display: flex;
            }
            #dashboard #user .dropdown-view .item p {
                font-weight: normal;
            }
        </style>

        <div id="app">
            <section id="dashboard" class="py-3">
                <h4 class="text-center">
                    Centauri CMS<br/>

                    <small>
                        v1.0.1 <small><i>EA 1</i></small>
                    </small>
                </h4>

                <div id="modules" class="mt-5">
                    <div class="module">
                        <div class="icon-view">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="#758CA3" fill-rule="evenodd" d="M10,9 C9.44771525,9 9,9.44771525 9,10 L9,21 C9,21.5522847 9.44771525,22 10,22 L21,22 C21.5522847,22 22,21.5522847 22,21 L22,10 C22,9.44771525 21.5522847,9 21,9 L10,9 Z M15,7 L15,3 C15,2.44771525 14.5522847,2 14,2 L3,2 C2.44771525,2 2,2.44771525 2,3 L2,14 C2,14.5522847 2.44771525,15 3,15 L7,15 L7,10 C7,8.34314575 8.34314575,7 10,7 L15,7 Z M17,7 L21,7 C22.6568542,7 24,8.34314575 24,10 L24,21 C24,22.6568542 22.6568542,24 21,24 L10,24 C8.34314575,24 7,22.6568542 7,21 L7,17 L3,17 C1.34314575,17 1.09108455e-15,15.6568542 8.8817842e-16,14 L0,3 C-2.02906125e-16,1.34314575 1.34314575,7.80279975e-16 3,8.8817842e-16 L14,8.8817842e-16 C15.6568542,6.15657427e-16 17,1.34314575 17,3 L17,7 Z"></path></svg>
                        </div>

                        <div class="text-view">
                            Pages
                        </div>
                    </div>
                </div>

                <div id="user">
                    <div class="d-flex">
                        <div class="avatar-view">
                            <span>
                                A
                            </span>
                        </div>

                        <div class="text-view">
                            <p class="m-0">
                                Admin
                            </p>

                            <p class="m-0">
                                Administrator
                            </p>

                            <i class="fas fa-chevron-down"></i>
                        </div>
                    </div>

                    <div class="dropdown-view" style="display: none;">
                        <div class="item">
                            <div class="icon-view">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="#758CA3" fill-rule="evenodd" d="M12,3 C9.790861,3 8,4.790861 8,7 C8,9.209139 9.790861,11 12,11 C14.209139,11 16,9.209139 16,7 C16,4.790861 14.209139,3 12,3 Z M12,1 C15.3137085,1 18,3.6862915 18,7 C18,10.3137085 15.3137085,13 12,13 C8.6862915,13 6,10.3137085 6,7 C6,3.6862915 8.6862915,1 12,1 Z M4,22.0990195 C4,22.6513043 3.55228475,23.0990195 3,23.0990195 C2.44771525,23.0990195 2,22.6513043 2,22.0990195 L2,20 C2,17.2385763 4.23857625,15 7,15 L17.0007003,15 C19.7621241,15 22.0007003,17.2385763 22.0007003,20 L22.0007003,22.0990195 C22.0007003,22.6513043 21.5529851,23.0990195 21.0007003,23.0990195 C20.4484156,23.0990195 20.0007003,22.6513043 20.0007003,22.0990195 L20.0007003,20 C20.0007003,18.3431458 18.6575546,17 17.0007003,17 L7,17 C5.34314575,17 4,18.3431458 4,20 L4,22.0990195 Z"></path></svg>
                            </div>

                            <div class="text-view">
                                <p class="m-0">
                                    Dein Profil
                                </p>
                            </div>
                        </div>

                        <div class="item">
                            <div class="icon-view">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="#758CA3" fill-rule="evenodd" d="M20.5857864,13 L5,13 C4.44771525,13 4,12.5522847 4,12 C4,11.4477153 4.44771525,11 5,11 L20.5857864,11 L18.2928932,8.70710678 C17.9023689,8.31658249 17.9023689,7.68341751 18.2928932,7.29289322 C18.6834175,6.90236893 19.3165825,6.90236893 19.7071068,7.29289322 L23.7071068,11.2928932 C24.0976311,11.6834175 24.0976311,12.3165825 23.7071068,12.7071068 L19.7071068,16.7071068 C19.3165825,17.0976311 18.6834175,17.0976311 18.2928932,16.7071068 C17.9023689,16.3165825 17.9023689,15.6834175 18.2928932,15.2928932 L20.5857864,13 Z M14,7 C14,7.55228475 13.5522847,8 13,8 C12.4477153,8 12,7.55228475 12,7 L12,4.69425418 C12,4.20541502 11.646587,3.78822491 11.164399,3.70786025 L3.16439899,2.37452692 C2.61962867,2.28373187 2.10440113,2.65175153 2.01360608,3.19652186 C2.00455084,3.25085328 2,3.30583998 2,3.36092084 L2,20.6390792 C2,21.1913639 2.44771525,21.6390792 3,21.6390792 C3.05508086,21.6390792 3.11006756,21.6345283 3.16439899,21.6254731 L11.164399,20.2921397 C11.646587,20.2117751 12,19.794585 12,19.3057458 L12,17 C12,16.4477153 12.4477153,16 13,16 C13.5522847,16 14,16.4477153 14,17 L14,19.3057458 C14,20.7722633 12.9397609,22.0238336 11.493197,22.2649276 L3.49319696,23.5982609 C3.33020268,23.6254266 3.16524258,23.6390792 3,23.6390792 C1.34314575,23.6390792 3.55271368e-15,22.2959334 0,20.6390792 L0,3.36092084 C0,3.19567826 0.0136525156,3.03071816 0.0408182285,2.86772388 C0.313203389,1.23341292 1.858886,0.129353911 3.49319696,0.401739072 L11.493197,1.73507241 C12.9397609,1.97616639 14,3.22773672 14,4.69425418 L14,7 Z"></path></svg>
                            </div>

                            <div class="text-view">
                                <p class="m-0">
                                    <a href="/centauri/logout">
                                        Abmelden
                                    </a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id="content"></section>
        </div>

        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

        <script>
            const Centauri = {};

            Centauri.dashboard = function() {
                $("#dashboard #user i").on("click", function() {
                    $("#dashboard #user").toggleClass("active");
                    $("#dashboard #user .dropdown-view").slideToggle();
                });
            };

            $(document).ready(function() {
                Centauri.dashboard();
            });
        </script>
    </body>
</html>
<?php /**PATH /app/resources/views/Backend/backend.blade.php ENDPATH**/ ?>