<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Centauri - Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>

<body>
    <div class="overlayer"></div>

    <style>
        body {
            background: linear-gradient(90deg, rgba(40,40,66,1) 51%, rgba(36,189,195,1) 51%);
        }

        body > .container {
            margin-top: 25%;
            transform: translateY(-50%);
            box-shadow: 0 0 25px #000;
            color: white;
        }

        #login {
            position: absolute;
            top: 50%;
            left: calc(75% - 30px);
            width: 100%;
            transform: translate(-50%, -50%);
        }

        .centauri-notifications {
            position: absolute;
            top: 165px;
            right: 20px;
            bottom: auto;
            left: auto;
            width: 400px;
            z-index: 99;
            max-height: calc(100% - 20px);
            overflow: hidden;
        }

        .centauri-notifications .item {
            font-family: Source Sans Pro, Helvetica Neue, Helvetica, Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            box-sizing: border-box;
            padding: 0;
            border-radius: 4px;
            color: #52667a;
            text-align: left;
            position: relative;
            margin: 0 auto 20px;
            font-size: 14px;
            box-shadow: 1px 2px 5px rgba(0, 0, 0, .1);
            border: 1px solid #d1d9e0;
            border-left-width: 4px;
            width: 100%;
            background-color: #fff;
            border-color: #d1d9e0 #d1d9e0 #d1d9e0 #de294c;
        }

        .centauri-notifications .item[data-layout="error"] svg path {
            fill: #de294c;
        }

        .centauri-notifications .item svg {
            font-family: Source Sans Pro, Helvetica Neue, Helvetica, Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            text-align: left;
            font-size: 14px;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            vertical-align: middle;
            line-height: 0;
            position: absolute;
            display: block;
            left: 15px;
            top: 15px;
            color: #de294c;
            width: 20px;
            height: 20px;
        }
    </style>

    <?php if($errors->any()): ?>
        <div class="centauri-notifications">
            <div class="item px-5 p-3" data-layout="error">
                <span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                        <path fill="#758CA3" fill-rule="evenodd" d="M10.5857864,12 L8.29289322,9.70710678 C7.90236893,9.31658249 7.90236893,8.68341751 8.29289322,8.29289322 C8.68341751,7.90236893 9.31658249,7.90236893 9.70710678,8.29289322 L12,10.5857864 L14.2928932,8.29289322 C14.6834175,7.90236893 15.3165825,7.90236893 15.7071068,8.29289322 C16.0976311,8.68341751 16.0976311,9.31658249 15.7071068,9.70710678 L13.4142136,12 L15.7071068,14.2928932 C16.0976311,14.6834175 16.0976311,15.3165825 15.7071068,15.7071068 C15.3165825,16.0976311 14.6834175,16.0976311 14.2928932,15.7071068 L12,13.4142136 L9.70710678,15.7071068 C9.31658249,16.0976311 8.68341751,16.0976311 8.29289322,15.7071068 C7.90236893,15.3165825 7.90236893,14.6834175 8.29289322,14.2928932 L10.5857864,12 Z M7.24264069,0 L16.7573593,0 C17.5530088,-1.46158436e-16 18.3160705,0.316070521 18.8786797,0.878679656 L23.1213203,5.12132034 C23.6839295,5.68392948 24,6.44699122 24,7.24264069 L24,16.7573593 C24,17.5530088 23.6839295,18.3160705 23.1213203,18.8786797 L18.8786797,23.1213203 C18.3160705,23.6839295 17.5530088,24 16.7573593,24 L7.24264069,24 C6.44699122,24 5.68392948,23.6839295 5.12132034,23.1213203 L0.878679656,18.8786797 C0.316070521,18.3160705 9.74389576e-17,17.5530088 0,16.7573593 L0,7.24264069 C2.12300709e-15,6.44699122 0.316070521,5.68392948 0.878679656,5.12132034 L5.12132034,0.878679656 C5.68392948,0.316070521 6.44699122,1.47842607e-15 7.24264069,0 Z M7.24264069,2 C6.9774242,2 6.72307028,2.10535684 6.53553391,2.29289322 L2.29289322,6.53553391 C2.10535684,6.72307028 2,6.9774242 2,7.24264069 L2,16.7573593 C2,17.0225758 2.10535684,17.2769297 2.29289322,17.4644661 L6.53553391,21.7071068 C6.72307028,21.8946432 6.9774242,22 7.24264069,22 L16.7573593,22 C17.0225758,22 17.2769297,21.8946432 17.4644661,21.7071068 L21.7071068,17.4644661 C21.8946432,17.2769297 22,17.0225758 22,16.7573593 L22,7.24264069 C22,6.9774242 21.8946432,6.72307028 21.7071068,6.53553391 L17.4644661,2.29289322 C17.2769297,2.10535684 17.0225758,2 16.7573593,2 L7.24264069,2 Z"></path>
                    </svg>
                </span>

                <div class="title">
                    Fehler
                </div>

                <div class="message">
                    <?php echo $errors->default->getMessages()["LOGIN_FAILED_MESSAGE"][0]; ?>

                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="container">
        <div class="row">
            <div class="col-6 d-none d-md-block">
                <img src="/images/background.png" class="img-fluid w-100" alt="" style="margin-left: -15px;">
            </div>

            <div id="login" class="col-12 col-md-4">
                <h4 class="text-center" style="margin: 15px 0 30px;">
                    Login
                </h4>

                <form action="/centauri/login" method="post">
                    <?php echo csrf_field(); ?>

                    <input class="form-control mb-3" type="text" name="username" id="username" placeholder="Username" />
                    <input class="form-control mb-4" type="password" name="password" id="password" placeholder="Password" />

                    <div class="row">
                        <div class="col-6 mx-auto mt-2">
                            <input type="submit" value="Login" class="form-control" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH /app/resources/views/Backend/login.blade.php ENDPATH**/ ?>