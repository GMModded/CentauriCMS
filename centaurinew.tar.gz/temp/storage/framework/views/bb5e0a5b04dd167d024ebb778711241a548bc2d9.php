<h1>
    frontend.blade.php - frontend
</h1>
<?php /**PATH /app/resources/views/frontend.blade.php ENDPATH**/ ?>