<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Centauri - Backend</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    </head>

    <body>
        <style>
            html,
            body,
            #app {
                height: 100%;
                overflow: hidden;
                color: white;
            }

            #dashboard {
                width: 300px;
                background: linear-gradient(180deg,#303a4f,#2a3345);
                transition: width .4s cubic-bezier(.5,.32,.01,1);
                height: 100%;
                display: flex;
                flex-direction: column;
            }

            #dashboard .headings h5 {
                line-height: 15px;
            }
        </style>

        <div id="app">
            <section id="dashboard" class="p-3">
                <div class="headings">
                    <h5>
                        Centauri CMS<br/>

                        <small>
                            v1.0.3 EA 2
                        </small>
                    </h5>
                </div>
            </section>

            <section id="content">

            </section>
        </div>
    </body>
</html><?php /**PATH /app/resources/views/backend.blade.php ENDPATH**/ ?>