<?php
namespace Centauri\CMS\Http;

use App;
use Centauri\CMS\Centauri;
use Centauri\CMS\Component\ElementComponent;
use Facade\FlareClient\Http\Response;
use Illuminate\Http\Request as IlluminateRequest;
use Illuminate\Support\Str;

class Request
{
    /**
     * This function manages all requests before anything else happens
     * 
     * @param string $view - Can be either frontend or backend/centauri
     * 
     * @return void
     */
    public static function handle($nodes)
    {
        if($nodes == "centauri") {
            if(request()->session()->get("CENTAURI_BE_USER")) {
                return view("Backend.centauri");
            }

            return view("Backend.login");
        }

        if(Str::contains($nodes, "/")) {
            $nnodes = explode("/", $nodes);
            if($nnodes[0] == "centauri") {
                if($nnodes[1] == "ajax" || $nnodes[1] == "action") {
                    $classname = $nnodes[2];
                    $method = $nnodes[3];

                    $class = Centauri::makeInstance("\\Centauri\\CMS\\Controller\\" . $classname . "Controller");
                    $reflectionMyMethod = (new \ReflectionClass($class))->getMethod($method . ucfirst($nnodes[1]));

                    // $request = Request();
                    return $reflectionMyMethod->invoke($class, request());
                }
            }
        }

        $pages = App\Page::all();
        $page = null;

        foreach($pages as $pageObj) {
            $slugs = $pageObj->getAttribute("slugs");

            if(Str::contains($slugs, ",")) {
                $slugs = explode(",", $slugs);

                foreach($slugs as $slug) {
                    if($slug === $nodes) {
                        $page = $pageObj;
                        break;
                    }
                }
            } else {
                if($slugs !== "/" && substr($slugs, 0, 1) == "/") {
                    $slugs = substr_replace("/", "", 0, 1) . substr($slugs, 1, strlen($slugs));
                }

                if($slugs === $nodes) {
                    $page = $pageObj;
                    break;
                }
            }
        }

        if(is_null($page)) {
            dd("404");
        }

        $uid = $page->getAttribute("uid");
        ElementComponent::render("FE", $uid);
    }
}
