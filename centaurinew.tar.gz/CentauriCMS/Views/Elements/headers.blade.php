@if($data->ce_header)
    <h1>
        {{ $data->ce_header }}
    </h1>
@endif
