<?php
namespace Centauri\CMS\Utility;

class DBUtility
{
    
}
