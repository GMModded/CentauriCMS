<?php
namespace Centauri\CMS\Controller;

use Illuminate\Routing\Controller as BaseController;

class ModalController extends BaseController
{
    public function pageeditAjax()
    {
        return json_encode(["resp" => false]);
    }
}
