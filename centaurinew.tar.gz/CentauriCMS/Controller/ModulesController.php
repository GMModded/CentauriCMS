<?php
namespace Centauri\CMS\Controller;

use Illuminate\Http\Request;

class ModulesController
{
    public function showAjax(Request $request)
    {
        $moduleid = $request->input("moduleid");

        $data = $this->findDataByModuleid($moduleid);

        return view("Backend.Modules.$moduleid", [
            "data" => $data
        ]);
    }

    private function findDataByModuleid($moduleid)
    {
        if($moduleid == "pages") {
            $pages = \App\Page::all();

            return ["pages" => $pages];
        }

        return [];
    }
}
