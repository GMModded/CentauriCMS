<?php
namespace Centauri\CMS\Controller;

use Illuminate\Http\Request;

class BackendController
{
    public function loginAjax(Request $request)
    {
        $username = $request->input("username");
        $password = $request->input("password");

        if($username == "admin" && $password == "password") {
            $request->session()->put("CENTAURI_BE_USER", true);

            return json_encode([
                "type" => "success",
                "title" => "Welcome back, $username",
                "description" => "Enjoy your session!",

                "headtags" => [
                    ["title", "Centauri"]
                ]
            ]);
        }

        return json_encode([
            "type" => "error",
            "title" => "Login failed",
            "description" => "Username/password is wrong!"
        ]);
    }

    public function logoutAction(Request $request)
    {
        $request->session()->remove("CENTAURI_BE_USER");
        return redirect("/centauri");
    }
}
