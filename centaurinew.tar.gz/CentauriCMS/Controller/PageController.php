<?php
namespace Centauri\CMS\Controller;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use App\Page;

class PageController extends BaseController
{
    public function newPageAjax(Request $request)
    {
        $params = $request->input();

        $title = $params["title"];
        $url = $params["url"];

        $page = new Page;

        $page->title = $title;
        $page->slugs = $url;

        $existingPage = Page::where("slugs", $url)->first();

        if(is_null($existingPage)) {
            $existingPage = Page::where("title", $title)->first();

            if(is_null($existingPage)) {
                if($page->save()) {
                    return json_encode([
                        "type" => "success",
                        "title" => "Page '" . $title . "' saved",
                        "description" => "Successfuly saved '" . $title . "'"
                    ]);
                }

                return json_encode([
                    "type" => "error",
                    "title" => "New Page failed",
                    "description" => "An error occured while saving '" . $title . "'"
                ]);
            } else {
                return json_encode([
                    "type" => "error",
                    "title" => "Page exists",
                    "description" => "The page '" . $existingPage->title . "' has this title already!"
                ]);
            }
        } else {
            return json_encode([
                "type" => "error",
                "title" => "Page exists",
                "description" => "The page '" . $existingPage->title . "' has this URL already!"
            ]);
        }
    }

    public function editPageAjax(Request $request)
    {
        $params = $request->input();

        $uid = $params["uid"];

        dd($params);

        $title = $params["title"];
        $url = $params["url"];

        $page = Page::find($uid);

        $page->title = $title;
        $page->slugs = $url;

        if($page->save()) {
            return json_encode([
                "type" => "success",
                "title" => "Page '" . $title . "' updated",
                "description" => "Successfuly updated '" . $title . "'"
            ]);
        }

        return json_encode([
            "type" => "error",
            "title" => "Updating Page failed",
            "description" => "An error occured while updating '" . $title . "'"
        ]);
    }
}
