Centauri.Events.OnModuleEvent = function(module) {
    if(module == "pages") {
        Centauri.Components.PagesComponent();

        $("#pagemodule_buttons button").each(function() {
            $button = $(this);

            $button.on("click", this, function() {
                Centauri.Components.EditorComponent("show", {
                    id: "CreateNewPage",
                    title: "Page-Editor - New",

                    form: [
                        {
                            id: "title",
                            type: "text",
                            placeholder: "Title"
                        },

                        {
                            id: "url",
                            type: "text",
                            placeholder: "URLs"
                        }
                    ],

                    callbacks: {
                        save: function() {
                            CentauriAjax(
                                "Page",
                                "newPage",

                                {
                                    title: $("#CreateNewPage_title").val(),
                                    url: $("#CreateNewPage_url").val()
                                },

                                {
                                    success: function(data) {
                                        data = JSON.parse(data);
                                        toastr[data.type](data.title, data.description);

                                        Centauri.Components.EditorComponent("clear");
                                        Centauri.Components.EditorComponent("hide");

                                        Centauri.Components.ModulesComponent({
                                            type: "load",
                                            module: "pages"
                                        });
                                    },

                                    error: function(data) {
                                        console.error(data);
                                    }
                                }
                            );
                        }//,cancel: function() {}
                    }
                });
            });
        });
    } else {
        console.error();
    }
};
