Centauri.Events.OnBackendEvent = function() {
    Centauri.load();
};
