Centauri.Utility.PathsUtility = {
    root: "/",
    ajax: "centauri/ajax/"
};
