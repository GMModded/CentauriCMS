const CentauriAjax = function(controller, method, data, callbacks) {
    $.ajax({
        url: Centauri.Utility.PathsUtility.root + Centauri.Utility.PathsUtility.ajax + controller + "/" + method,
        type: "POST",

        data: data,

        success: function(data) {
            callbacks.success(data);
        },
        error: function(data) {
            if(typeof callbacks.error !== undefined) {
                callbacks.error(data);
            } else {
                console.error(data);
            }
        }
    });
};

Centauri.Utility.Ajax = function() {
    $.ajaxSetup({
        headers: {
            "X-CSRF-TOKEN": $("meta[name='csrf-token']").attr("content")
        }
    });
};

window.onload = function() {
    Centauri.Utility.Ajax();
};
