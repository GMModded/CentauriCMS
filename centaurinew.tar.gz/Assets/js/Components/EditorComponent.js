Centauri.Components.EditorComponent = function(type, data) {
    var transitionTime = 660;

    $editor = $("#editor");

    if(type == "show") {
        $editor.addClass("active");

        var crtID   = $editor.attr("data-id");
        var id      = data.id,
            title   = data.title;

        $(".top > p", $editor).text(title);

        if(crtID !== id) {
            $editor.attr("data-id", id);
            $("form", $editor).empty();

            $.each(data.form, function(index, inputObj) {
                var extraAttr = "";
                var value = "";

                if(Centauri.isNotUndefined(inputObj.extraAttr)) {
                    extraAttr = " " + inputObj.extraAttr;
                }
                if(Centauri.isNotUndefined(inputObj.value)) {
                    value = inputObj.value;
                }

                $("form", $editor).append("<input class='form-control' type='" + inputObj.type + "' placeholder='" + inputObj.placeholder + "' value='" + value + "' id='" + id + "_" +  inputObj.id + "'" + extraAttr + " />");
            });

            if(!Centauri.Components.EditorComponent.ButtonsInitialized) {
                Centauri.Components.EditorComponent.ButtonsInitialized = true;

                $("button", $editor).each(function() {
                    $button = $(this);

                    $button.on("click", this, function() {
                        var dataID = $(this).data("id");

                        if(dataID == "save") {
                            data.callbacks.save();
                        }

                        if(dataID == "cancel") {
                            Centauri.Components.EditorComponent("hide");

                            if(typeof data.callbacks.cancel !== undefined && typeof data.callbacks.cancel !== "undefined") {
                                data.callbacks.cancel();
                            }
                        }
                    });
                });
            }
        }

        setTimeout(function() {
            $(".overlayer").removeClass("hidden");
            $(".overlayer").attr("data-closer", "EditorComponent");
        }, transitionTime);

        Centauri.Components.EditorComponent.init($editor);
    }

    if(type == "hide") {
        $editor.removeClass("active");

        setTimeout(function() {
            $(".overlayer").addClass("hidden");
            $(".overlayer").removeAttr("data-closer");
        }, transitionTime);
    }

    if(type == "clear") {
        $("form", $editor).empty();
        $editor.removeAttr("data-id");
    }
};

Centauri.Components.EditorComponent.init = function($editor) {
    $(".overlayer").on("click", this, function() {
        $(this).addClass("hidden");
        
        var closer = $(this).data("closer");
        Centauri.Events.OnOverlayerHiddenEvent(closer);
    });
};

Centauri.Components.EditorComponent.ButtonsInitialized = false;
