Centauri.Components.PagesComponent = function() {
    $action = $("table#pages .actions .action");

    $action.on("click", function() {
        var uid = $(this).attr("data-uid");
        var action = $(this).attr("data-action");

        if(action == "page-edit") {
            $tr = $(this).parent().parent().parent();

            var title = $.trim($("td[data-type='title']", $tr).text());
            var url = $.trim($("td[data-type='url']", $tr).text());
            var created_at = $.trim($("td[data-type='created_at']", $tr).text());
            var updated_at = $.trim($("td[data-type='updated_at']", $tr).text());

            Centauri.Components.EditorComponent("show", {
                id: "EditPage-" + uid,
                title: "Page-Editor - Edit",

                form: [
                    {
                        id: "uid",
                        type: "text",
                        value: uid,
                        extraAttr: "readonly"
                    },

                    {
                        id: "title",
                        type: "text",
                        placeholder: "Title",
                        value: title
                    },

                    {
                        id: "url",
                        type: "text",
                        placeholder: "URLs",
                        value: url
                    },

                    {
                        id: "created_at",
                        type: "text",
                        value: created_at,
                        extraAttr: "readonly"
                    },

                    {
                        id: "updated_at",
                        type: "text",
                        value: updated_at,
                        extraAttr: "readonly"
                    }
                ],

                callbacks: {
                    save: function() {
                        var id = $("#editor").attr("data-id");

                        CentauriAjax(
                            "Page",
                            "editPage",

                            {
                                uid: uid,
                                title: $("#" + id + "_title").val(),
                                url: $("#" + id + "_url").val()
                            },

                            {
                                success: function(data) {
                                    data = JSON.parse(data);
                                    toastr[data.type](data.title, data.description);

                                    Centauri.Components.EditorComponent("clear");
                                    Centauri.Components.EditorComponent("hide");

                                    Centauri.Components.ModulesComponent({
                                        type: "load",
                                        module: "pages"
                                    });
                                },

                                error: function(data) {
                                    console.error(data);
                                }
                            }
                        );
                    }//,cancel: function() {}
                }
            });
        }
    });
};
