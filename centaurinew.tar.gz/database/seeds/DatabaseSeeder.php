<?php

use App\Page;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        echo "\n";
        echo "Starting Database Seed...\n\n";


        // Backend Users
        $users = \App\BeUser::all();

        if(count($users) == 0) {
            DB::table("be_users")->insert([
                "username" => "admin",
                "password" => bcrypt("password"),
                "created_at" => date("Y-m-d H:i:s"),
                "updated_at" => date("Y-m-d H:i:s")
            ]);

            echo "Created a backend user (admin & password).\n";
        } else {
            echo "Atleast one beuser has been found in be_users-table.\n";
        }


        // Pages
        $pages = \App\Page::all();

        if(count($pages) == 0) {
            DB::table("pages")->insert([
                "lid" => 0,
                "title" => "Home",
                "slugs" => "/",
                "created_at" => date("Y-m-d H:i:s"),
                "updated_at" => date("Y-m-d H:i:s")
            ]);

            echo "Created a home page.\n";
        } else {
            echo "Atleast one page has been found in pages-table.\n";
        }


        // Elements
        $elements = \App\Element::all();

        if(count($elements) == 0) {
            DB::table("elements")->insert([
                "pid" => 1,
                "lid" => 0,
                "ctype" => "headers",

                "data" => json_encode([
                    "ce_header" => "Willkommen zum Centauri CMS!"
                ]),

                "created_at" => date("Y-m-d H:i:s"),
                "updated_at" => date("Y-m-d H:i:s")
            ]);

            echo "Created a dummy-element on your root page.\n";
        } else {
            echo "Atleast one element has been found in elements-table.\n";
        }





        echo "\n";
        echo "Database Seeder finished.\n";
    }
}
