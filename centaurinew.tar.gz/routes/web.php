<?php

use Centauri\CMS\Centauri;
use Centauri\CMS\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get("/", function() {
    return Request::handle("/");
});


Route::post("/centauri/ajax/{controller}/{ajax}", function($controller, $ajax) {
    $controllerClass = Centauri::makeInstance("\\Centauri\\CMS\\Controller\\" . $controller . "Controller");

    return call_user_func(
        [
            $controllerClass,
            $ajax . "Ajax"
        ],

        request()
    );
});
Route::get("/centauri/action/{controller}/{action}", function($controller, $action) {
    $controllerClass = Centauri::makeInstance("\\Centauri\\CMS\\Controller\\" . $controller . "Controller");

    return call_user_func(
        [
            $controllerClass,
            $action . "Action"
        ],

        request()
    );
});


Route::get("{nodes}", function($nodes = []) {
    return Request::handle($nodes);
})->where(["nodes" => ".*"]);
