<div class="container">
	<div class="row">
		<div class="col-12">
			<h3 id="title">
				Centauri - Dashboard
			</h3>

			<hr>

			<section class="mt-md-4 pt-md-2 mb-5 pb-4">
				
			</section>
		</div>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\CentauriCMS\resources\views/Backend/Modules/dashboard.blade.php ENDPATH**/ ?>