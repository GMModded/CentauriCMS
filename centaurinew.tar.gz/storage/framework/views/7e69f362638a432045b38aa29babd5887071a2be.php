<h1>
    404 Seite nicht gefunden - rip.
</h1>
<?php /**PATH C:\xampp\htdocs\CentauriCMS\Centauri\CMS\Views/404.blade.php ENDPATH**/ ?>