<?php if($data->ce_header): ?>
    <h1>
        <?php echo e($data->ce_header); ?>

    </h1>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\CentauriCMS\Centauri\CMS\Views/Elements/headers.blade.php ENDPATH**/ ?>