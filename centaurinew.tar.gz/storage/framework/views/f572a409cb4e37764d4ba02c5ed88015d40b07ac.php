<h1>
    <?php echo e($data->ce_header); ?>

</h1>
<?php /**PATH C:\xampp\htdocs\CentauriCMS\resources\views/Frontend/Elements/headers.blade.php ENDPATH**/ ?>