<div class="container">
    <div class="row">
        <div class="col-12">
            <h3 id="title">
                Centauri - Pages
            </h3>

            <hr>

            <table id="pages" class="table table-dark table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>
                            UID
                        </th>

                        <th>
                            Title
                        </th>

                        <th>
                            URLs
                        </th>

                        <th>
                            Created at
                        </th>

                        <th>
                            Modified at
                        </th>

                        <th>
                            Actions
                        </th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $data["pages"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-type="uid">
                                # <?php echo e($page->uid); ?>

                            </td>

                            <td data-type="title">
                                <?php echo e($page->title); ?>

                            </td>

                            <td data-type="url">
                                <?php echo e($page->slugs); ?>

                            </td>

                            <td data-type="created_at">
                                <?php echo e($page->created_at); ?>

                            </td>

                            <td data-type="updated_at">
                                <?php echo e($page->updated_at); ?>

                            </td>

                            <td>
                                <div class="actions">
                                    <div class="action mr-3" data-action="page-edit" data-uid="<?php echo e($page->uid); ?>">
                                        <i class="fas fa-pen fa-lg"></i>
                                    </div>

                                    <div class="action" data-action="page-contentelement-edit" data-uid="<?php echo e($page->uid); ?>">
                                        <i class="fab fa-elementor fa-lg"></i>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div id="pagemodule_buttons" class="col-12 text-right">
            <button class="btn btn-primary btn-floating waves-effect waves-light" data-button-type="create">
                <i class="fas fa-plus"></i>
            </button>

            <button class="btn btn-success btn-floating waves-effect waves-light" data-button-type="save">
                <i class="fas fa-save"></i>
            </button>

            <button class="btn btn-danger btn-floating waves-effect waves-light" data-button-type="cancel">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>
</div>
<?php /**PATH /app/resources/views/Backend/Modules/pages.blade.php ENDPATH**/ ?>