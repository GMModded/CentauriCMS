<div class="container">
    <div class="row">
        <div class="col-12">
            <h3 id="title">
                Centauri - Pages
            </h3>

            <hr>

            <table class="table table-dark table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>
                            UID
                        </th>

                        <th>
                            Title
                        </th>

                        <th>
                            URLs
                        </th>

                        <th>
                            Created at
                        </th>

                        <th>
                            Modified at
                        </th>

                        <th>
                            Actions
                        </th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $data["pages"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                # <?php echo e($page->uid); ?>

                            </td>

                            <td contenteditable="true">
                                <?php echo e($page->title); ?>

                            </td>

                            <td contenteditable="true">
                                <?php echo e($page->slugs); ?>

                            </td>

                            <td>
                                <?php echo e($page->created_at); ?>

                            </td>

                            <td>
                                <?php echo e($page->updated_at); ?>

                            </td>

                            <td>
                                <a href="<?php echo e(url('centauri/ajax/Modal/pageedit')); ?>" class="mr-3" data-ajax="Modal;pageedit">
                                    <i class="fas fa-pen"></i>
                                </a>
                                <i class="fas fa-trash"></i>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="col-12 text-right">
            <button class="btn btn-danger waves-effect waves-light" data-button-type="cancel">
                <i class="fas fa-times mr-1"></i>
                Cancel
            </button>

            <button class="btn btn-success waves-effect waves-light mr-0" data-button-type="save">
                <i class="fas fa-save mr-1"></i>
                Save
            </button>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\CentauriCMS\resources\views/Backend/Modules/pages.blade.php ENDPATH**/ ?>