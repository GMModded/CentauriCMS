<h1>
    <?php echo e(app()->getLocale()); ?>

</h1>
<?php /**PATH C:\xampp\htdocs\CentauriCMS\resources\views/frontend.blade.php ENDPATH**/ ?>