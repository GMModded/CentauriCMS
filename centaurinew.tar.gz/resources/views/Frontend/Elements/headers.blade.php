<h1>
    {{ $data->ce_header }}
</h1>
