<h1>
    {{ app()->getLocale() }}
</h1>
